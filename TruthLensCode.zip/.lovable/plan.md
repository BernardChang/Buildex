# TruthLens — Settings Customization + Interactive Overhaul

This is a large request. I'll ship it in two coordinated phases so you can review after each. Phase 1 lands the settings system + the highest-impact interactive upgrades. Phase 2 polishes the remaining surfaces (graph, claims, landing).

## Phase 1 — Settings + Core Experience

### 1. Settings page (`/settings`)
A real preferences panel, persisted to `localStorage` (no DB schema change) under a `truthlens.prefs` key, exposed via a `usePreferences()` hook so any component can read/write.

Toggles & controls:
- **Appearance**
  - Theme: System / Light / Dark
  - Accent color: Slate (default) / Blue / Violet / Emerald
  - Density: Comfortable / Compact
  - Reduce motion (disables lift/pop animations)
- **Analysis defaults**
  - Default analysis type: Reliability / Gaps / Full
  - Default depth: Quick / Standard / Deep
  - Auto-run after upload (on/off)
- **Interface modules** (turn features on/off)
  - Guided upload flow
  - Smart loading messages
  - Score breakdown expansions
  - External evidence panel
  - Research gap cards
  - Key claims panel
  - Knowledge graph
  - Side assistant
- **Language**
  - Plain-English mode (rewrites verdicts in simpler tone)

Each setting has a one-line description and a Reset button.

### 2. Guided upload flow (`/upload`)
Replace the single dropzone with a 4-step wizard (skippable via settings):
1. Upload paper (drag/drop, glow on dragover)
2. Analysis type — Reliability / Gap Finder / Full
3. Depth — Quick Scan / Standard / Deep Research
4. Run

Stepper with progress dots, back/next, smooth transitions. Honors `autoRun` pref by jumping straight to step 4.

### 3. Smart loading experience
Replace spinner with a sequenced status list ("Reading paper…", "Extracting claims…", "Searching OpenAlex / Semantic Scholar / CrossRef…", "Comparing related papers…", "Identifying contradictions…", "Finding research gaps…", "Building reliability score…"). Each line fades in with a check when complete. Can be disabled in settings.

### 4. Reliability score card upgrade
- Large animated score (counts from 0)
- Verdict line in plain English
- Risk badge (Low/Medium/High) — color-coded but restrained
- Confidence chip
- Hover tooltips on each label explaining what it means

### 5. Interactive score breakdown
Each category becomes a click-to-expand row showing: Score · Explanation · Evidence found · Why points were lost · How to improve. Smooth accordion.

## Phase 2 — Evidence, Graph, Assistant, Landing

### 6. External evidence panel ("Compared Against the Literature")
Tabs: Supporting / Contradicting / Related / Reviews / Retraction warnings. Cards show title, year, citations, source (OpenAlex / Semantic Scholar / CrossRef), relationship badge, short explanation.

### 7. Research gap cards
Each gap: title · why it matters · missing variable · suggested research question · difficulty · impact · novelty. Actions: Save · Expand · Generate experiment idea · Find related papers.

### 8. Key claims panel
List of extracted claims with status badges (Supported / Mixed / Challenged / Unverified), confidence, and reasoning.

### 9. Knowledge graph polish
Minimal node/edge view (uploaded paper at center, supports/contradicts/related/gaps around it). Click node → side panel detail.

### 10. Conversational side assistant
Promote the existing "Ask TruthLens" into a right-side drawer with quick-prompt chips ("Why did this lose points?", "Biggest weakness?", "Explain like high school", etc.). Uses existing `askAboutAnalysis` server fn.

### 11. Empty states + language pass
Friendly empty-state copy across upload / history / no-evidence. Plain-English rewrites of verdicts when the pref is on.

### 12. Landing page sharpen
New hero copy, two CTAs, three feature cards.

## Technical Notes

- **Preferences**: new file `src/lib/preferences.tsx` — React context + `usePreferences()` hook + `localStorage` sync. Wrap app in `__root.tsx`.
- **Theme**: existing `dark` class on `<html>`; preference hook toggles it + listens to `prefers-color-scheme` when set to System.
- **Accent**: swap `--primary` / `--ring` token values on `:root` via a `data-accent` attribute mapping in `styles.css`.
- **Reduce motion**: add `data-reduce-motion` attr; CSS gates `.tlx-lift`, `.tlx-tap`, `.tlx-pop`, and the button hover-translate.
- **No backend changes** for settings (pure client). Analysis pipeline already accepts type/depth-like params; we'll pass them through but keep server behavior unchanged unless a deeper pass is requested.
- **Module toggles** simply conditionally render sections in `results.$id.tsx` and `upload.tsx`.

## Out of scope (unless you ask)
- DB-backed per-user preferences (would need a `preferences` table + RLS)
- Server-side analysis behavior changes beyond plumbing type/depth
- Real knowledge-graph physics engine — staying with the existing lightweight viz

Approve and I'll start Phase 1.